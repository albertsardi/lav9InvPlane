<?php if (! defined(‘BASEPATH’)) exit(‘No direct script access allowed’);

class db {
	public function read_array() {
		//do stuff		
	}
}


?>
