                <div class="card">
                    <div class="card-content p-2">
                        <div class="cell text-left">
                            <button id="cmSave" type="button" class="button primary">Save</button>
                            <button id="cmPrint" type="button" class="button primary">Print</button>
                            <button id="cmJournal" type="button" class="button secondary">Journal</button>
                        </div>
                        <div class="cell text-right">
                            <div id='info' ></div>
                        </div>
                    </div>
                </div>