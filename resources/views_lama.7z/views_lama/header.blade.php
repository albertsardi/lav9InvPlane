<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Allegro - ERP System Administrator</title>
<meta name="description" content="Allegro - ERP System Administrtor">
<meta name="author" content="Albert - (c)ASAfoodenesia">

<!-- Favicon -->
<link rel="shortcut icon" href="assets/images/favicon.ico">

<!-- Bootstrap CSS -->
<link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />

<!-- Font Awesome CSS -->
<link href="assets/css/fontawesome/font-awesome.min.css" rel="stylesheet" type="text/css" />

<!-- CSS page -->
<link href="assets/css/datepicker.css" rel="stylesheet" type="text/css" />
<link href="assets/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />

<!-- Custom CSS -->
<link href="assets/css/style.css" rel="stylesheet" type="text/css" />
