            <div class="card card-body mb-2">
				<div class="form-group row">
					<div class="col-sm-10">
				  		<button id='cmSave' type="button" class="btn btn-primary">Save</button>
			  			<button id='cmPrint' type="submit" class="btn btn-primary">Print</button>
					</div>
			  	</div>
			</div>