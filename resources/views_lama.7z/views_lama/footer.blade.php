<div class="footer">
	<span class="text-right">Copyright <a target="_blank" href="#">Allegro.ID</a></span>
	<span class="float-right">Powered by <a target="_blank" href="https://www.intersoft.web.id"><b>@AlbertSardi@gmail.com</b></a></span>
</div>